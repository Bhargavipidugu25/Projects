package com.wipro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*
 * Run Spring Boot project. Open the browser and type in the foll. url:
	http://localhost:9091/swagger-ui/index.html
	
	To connect to Oracle VM, run the foll. at the terminal:
	 sudo service oracle-xe start
	 
	 Access the database in the foll. url:
	 	http://127.0.0.1:9500/apex
	 	
	 IN project's Build Path, set the arguments as:
	 	-Doracle.jdbc.timezoneAsRegion=false
	 	
 */
@SpringBootApplication
public class SpringBootJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaApplication.class, args);
	}

}
